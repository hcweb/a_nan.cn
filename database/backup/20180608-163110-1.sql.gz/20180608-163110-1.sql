-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2018-06-08 16:31:10
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `categorys`
-- -----------------------------
DROP TABLE IF EXISTS `categorys`;
CREATE TABLE `categorys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '栏目标题',
  `route` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '栏目路由名称',
  `target` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self' COMMENT '栏目打开方式',
  `icon_class` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '栏目图标',
  `color` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '栏目颜色',
  `height_url` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '栏目高亮',
  `parent_id` int(11) unsigned DEFAULT NULL COMMENT '父类id',
  `order` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '栏目排序',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `alias` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '调用别名',
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SEO标题',
  `seo_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SEO关健字',
  `seo_content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SEO描述',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'URL链接,填写后直接跳转到该网址',
  `thumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '封面图片',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '栏目描述',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `_lft` int(10) unsigned NOT NULL,
  `_rgt` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorys_title_unique` (`title`),
  UNIQUE KEY `categorys_alias_unique` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `categorys`
-- -----------------------------
INSERT INTO `categorys` VALUES ('10', '文章', 'category', '_self', '', '', '', '', '0', '1', 'article', '', '', '', '', '', '', '2018-05-27 16:41:11', '2018-05-27 16:41:11', '1', '8');
INSERT INTO `categorys` VALUES ('11', 'php', 'category/php', '_self', '', '', '', '10', '0', '1', 'php', '', '', '', '', '', '', '2018-05-27 20:02:53', '2018-05-27 20:02:53', '2', '3');
INSERT INTO `categorys` VALUES ('12', 'laravel', 'category/laravel', '_self', '', '', '', '10', '0', '1', 'laravel', '', '', '', '', '', '', '2018-05-27 20:03:22', '2018-05-27 20:03:22', '4', '5');
INSERT INTO `categorys` VALUES ('13', 'css3', 'category/css3', '_self', '', '', '', '10', '0', '1', 'css3', '', '', '', '', '', '', '2018-05-27 20:05:23', '2018-05-27 20:05:23', '6', '7');
INSERT INTO `categorys` VALUES ('14', '留言', 'message', '_self', '', '', '', '', '0', '1', 'leaving-a-message', '', '', '', '', '', '', '2018-05-27 20:06:09', '2018-05-27 20:06:09', '9', '10');
INSERT INTO `categorys` VALUES ('15', '实验室', 'laboratory', '_self', '', '', '', '', '0', '1', 'laboratory', '', '', '', '', '', '', '2018-05-27 20:06:44', '2018-05-27 20:06:44', '11', '12');
INSERT INTO `categorys` VALUES ('16', '关于', 'about', '_self', '', '', '', '', '0', '1', 'about', '', '', '', '', '', '', '2018-05-27 20:07:00', '2018-05-27 20:07:00', '13', '14');

-- -----------------------------
-- Table structure for `comments`
-- -----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '评论的标题',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '评论的内容',
  `visitor` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '所在城市',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '审核状态',
  `member_id` int(10) unsigned NOT NULL COMMENT '会员id',
  `post_id` int(10) unsigned NOT NULL COMMENT '会员id',
  `parent_id` int(10) unsigned DEFAULT NULL,
  `_lft` int(10) unsigned NOT NULL DEFAULT '0',
  `_rgt` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_member_id_foreign` (`member_id`),
  KEY `comments_post_id_foreign` (`post_id`),
  KEY `comments__lft__rgt_parent_id_index` (`_lft`,`_rgt`,`parent_id`),
  CONSTRAINT `comments_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `comments`
-- -----------------------------
INSERT INTO `comments` VALUES ('61', '', '<img src=/static/qqFace/arclist/9.gif border=0 >无限级评论实现 哈哈', '112.115.223.65', '云南.昆明', '1', '85', '6', '', '1', '10', '2018-05-26 23:48:46', '2018-05-26 23:48:46');
INSERT INTO `comments` VALUES ('62', '', '大神牛逼呀 呵呵', '112.115.223.65', '云南.昆明', '1', '83', '6', '61', '2', '9', '2018-05-26 23:55:03', '2018-05-26 23:55:03');
INSERT INTO `comments` VALUES ('63', '', '真好 哈哈哈哈哈哈哈', '112.115.223.65', '云南.昆明', '1', '84', '6', '62', '3', '6', '2018-05-26 23:56:06', '2018-05-26 23:56:06');
INSERT INTO `comments` VALUES ('64', '', '<img src=/static/qqFace/arclist/4.gif border=0 ><img src=/static/qqFace/arclist/41.gif border=0 >温热无若我认为认为认为认为认为认为', '112.115.223.65', '云南.昆明', '1', '84', '6', '', '11', '12', '2018-05-26 23:56:39', '2018-05-26 23:56:39');
INSERT INTO `comments` VALUES ('65', '', '所发生的发生的发生的发生的发生的发生的发生的发生的发生的', '112.115.223.65', '云南.昆明', '1', '85', '6', '63', '4', '5', '2018-05-26 23:58:34', '2018-05-26 23:58:34');
INSERT INTO `comments` VALUES ('66', '', '阿荣旗二却日期日期', '112.115.223.65', '云南.昆明', '1', '85', '6', '62', '7', '8', '2018-05-26 23:59:27', '2018-05-26 23:59:27');
INSERT INTO `comments` VALUES ('67', '', '博主牛逼呀', '218.63.137.67', '云南.昆明', '0', '84', '4', '', '13', '14', '2018-05-30 09:36:33', '2018-05-30 09:36:33');
INSERT INTO `comments` VALUES ('68', '', 'erterterterterterterter', '218.63.137.67', '云南.昆明', '0', '84', '6', '', '15', '16', '2018-05-30 12:24:23', '2018-05-30 12:24:23');

-- -----------------------------
-- Table structure for `link_items`
-- -----------------------------
DROP TABLE IF EXISTS `link_items`;
CREATE TABLE `link_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link_id` int(10) unsigned NOT NULL COMMENT '友情链接分类',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '友情链接标题',
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'url链接',
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '链接的logo',
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '链接描述',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系人',
  `user_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系人手机',
  `user_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系人邮箱',
  `order` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `link_items_title_unique` (`title`),
  KEY `link_items_link_id_foreign` (`link_id`),
  CONSTRAINT `link_items_link_id_foreign` FOREIGN KEY (`link_id`) REFERENCES `links` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `link_items`
-- -----------------------------
INSERT INTO `link_items` VALUES ('1', '2', '网易用户体验设计中心', 'http://uedc.163.com/', 'uploads/images/link/201804/01/site__1522555932_tBs3PjalnD.png', '', '1', '', '13577069756', '871328529@qq.com', '0', '2018-04-01 12:12:53', '2018-04-01 12:12:53');
