-- -----------------------------
-- Laravel MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2018-06-10 21:43:38
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `links`
-- -----------------------------
DROP TABLE IF EXISTS `links`;
CREATE TABLE `links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '友情链接分类名称',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `links_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `links`
-- -----------------------------
INSERT INTO `links` VALUES ('1', '前端博客', '2018-03-21 23:34:49', '2018-03-21 23:34:49');
INSERT INTO `links` VALUES ('2', '设计艺术', '2018-04-01 12:10:49', '2018-04-01 12:10:49');

-- -----------------------------
-- Table structure for `themes`
-- -----------------------------
DROP TABLE IF EXISTS `themes`;
CREATE TABLE `themes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主题名称',
  `theme` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主题模板',
  `username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'hcweb' COMMENT '模板用户名',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT '启用状态',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `themes`
-- -----------------------------
INSERT INTO `themes` VALUES ('3', '商城模板', 'shop', 'hcweb', '1', '2018-03-25 14:40:35', '2018-05-22 23:17:43');
INSERT INTO `themes` VALUES ('5', '博客主题', 'blog', 'admin', '0', '2018-03-25 16:07:48', '2018-05-22 23:17:41');
