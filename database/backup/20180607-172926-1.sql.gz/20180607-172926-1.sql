-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : a_nan
-- 
-- Part : #1
-- Date : 2018-06-07 17:29:26
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `blocks`
-- -----------------------------
DROP TABLE IF EXISTS `blocks`;
CREATE TABLE `blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '自定义资料标题',
  `type` char(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'F文字|I图片|E编辑',
  `body` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `blocks`
-- -----------------------------
INSERT INTO `blocks` VALUES ('5', '首页背景图', 'I', 'uploads/images/picture/201805/29/site__1527601630_x9pGghy5ek.png', '', '');
INSERT INTO `blocks` VALUES ('6', '个人头像', 'I', 'uploads/images/picture/201805/29/site__1527604326_FcPoa9hUK0.png', '', '');
