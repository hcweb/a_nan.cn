-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2018-06-08 16:31:41
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `blocks`
-- -----------------------------
DROP TABLE IF EXISTS `blocks`;
CREATE TABLE `blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '自定义资料标题',
  `type` char(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'F文字|I图片|E编辑',
  `body` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `blocks`
-- -----------------------------
INSERT INTO `blocks` VALUES ('5', '首页背景图', 'I', 'uploads/images/picture/201805/29/site__1527601630_x9pGghy5ek.png', '', '');
INSERT INTO `blocks` VALUES ('6', '个人头像', 'I', 'uploads/images/picture/201805/29/site__1527604326_FcPoa9hUK0.png', '', '');

-- -----------------------------
-- Table structure for `categorys`
-- -----------------------------
DROP TABLE IF EXISTS `categorys`;
CREATE TABLE `categorys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '栏目标题',
  `route` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '栏目路由名称',
  `target` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self' COMMENT '栏目打开方式',
  `icon_class` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '栏目图标',
  `color` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '栏目颜色',
  `height_url` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '栏目高亮',
  `parent_id` int(11) unsigned DEFAULT NULL COMMENT '父类id',
  `order` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '栏目排序',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `alias` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '调用别名',
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SEO标题',
  `seo_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SEO关健字',
  `seo_content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SEO描述',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'URL链接,填写后直接跳转到该网址',
  `thumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '封面图片',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '栏目描述',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `_lft` int(10) unsigned NOT NULL,
  `_rgt` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorys_title_unique` (`title`),
  UNIQUE KEY `categorys_alias_unique` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------
-- Records of `categorys`
-- -----------------------------
INSERT INTO `categorys` VALUES ('10', '文章', 'category', '_self', '', '', '', '', '0', '1', 'article', '', '', '', '', '', '', '2018-05-27 16:41:11', '2018-05-27 16:41:11', '1', '8');
INSERT INTO `categorys` VALUES ('11', 'php', 'category/php', '_self', '', '', '', '10', '0', '1', 'php', '', '', '', '', '', '', '2018-05-27 20:02:53', '2018-05-27 20:02:53', '2', '3');
INSERT INTO `categorys` VALUES ('12', 'laravel', 'category/laravel', '_self', '', '', '', '10', '0', '1', 'laravel', '', '', '', '', '', '', '2018-05-27 20:03:22', '2018-05-27 20:03:22', '4', '5');
INSERT INTO `categorys` VALUES ('13', 'css3', 'category/css3', '_self', '', '', '', '10', '0', '1', 'css3', '', '', '', '', '', '', '2018-05-27 20:05:23', '2018-05-27 20:05:23', '6', '7');
INSERT INTO `categorys` VALUES ('14', '留言', 'message', '_self', '', '', '', '', '0', '1', 'leaving-a-message', '', '', '', '', '', '', '2018-05-27 20:06:09', '2018-05-27 20:06:09', '9', '10');
INSERT INTO `categorys` VALUES ('15', '实验室', 'laboratory', '_self', '', '', '', '', '0', '1', 'laboratory', '', '', '', '', '', '', '2018-05-27 20:06:44', '2018-05-27 20:06:44', '11', '12');
INSERT INTO `categorys` VALUES ('16', '关于', 'about', '_self', '', '', '', '', '0', '1', 'about', '', '', '', '', '', '', '2018-05-27 20:07:00', '2018-05-27 20:07:00', '13', '14');
